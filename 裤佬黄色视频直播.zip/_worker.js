// ============================================================
// 爱豆直播 M3U 代理 - Cloudflare Workers 版 (全量抓取版)
// 策略：/live.m3u 并发抓取所有分类的所有页，播放时 302 重定向
// ============================================================

const BASE = "https://ww7.aida3.xyz";
const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";
const PAGE_SIZE = 20;
const MAX_PAGES = 10; // 每个分类最大抓取页数，防止无限死循环

const TOP_LOGO = "https://jsnz.pages.dev/f/5ab7e916.gif";
const TOP_GROUP = "✈️TG频道@stymei";
const FIXED_VIDEO_URL = "https://tymov2.a.kwimgs.com/upic/2026/08/15/09/BMjAyNjA4MTUwOTE2MzRfNDI0MDI5NTBfMjA1NjA5Mjg4OTg3XzFfMw==_b_B664d90218f70be73e07dd3cf02d473f1.mp4";

const CATS = [
  ["new", "最近更新", { by: "vod_time" }],
  ["hot", "热门", { by: "vod_hits" }],
  ["good", "精选", { by: "vod_score" }],
  ["1", "国产", { type: "1", by: "vod_time" }],
  ["5", "传媒", { type: "5", by: "vod_time" }],
  ["2", "日韩", { type: "2", by: "vod_time" }],
  ["3", "欧美", { type: "3", by: "vod_time" }],
  ["4", "动漫", { type: "4", by: "vod_time" }],
  ["6", "免费", { type: "6", by: "vod_time" }],
];

// ---------------- AES-128 CBC ----------------
async function importKey(keyBytes) {
  return await crypto.subtle.importKey(
    "raw", keyBytes, { name: "AES-CBC", length: 128 }, false, ["encrypt", "decrypt"]
  );
}

async function aesCbcEncrypt(keyBytes, data) {
  const key = await importKey(keyBytes);
  const iv = keyBytes;
  const enc = await crypto.subtle.encrypt({ name: "AES-CBC", iv }, key, data);
  return new Uint8Array(enc);
}

async function aesCbcDecrypt(keyBytes, data) {
  const key = await importKey(keyBytes);
  const iv = keyBytes;
  const dec = await crypto.subtle.decrypt({ name: "AES-CBC", iv }, key, data);
  return new Uint8Array(dec);
}

// ---------------- API 参数 ----------------
function apiKey(t) {
  const s = (String(t * 299) + "1").split("").reverse().join("");
  return new TextEncoder().encode(s);
}

function apiMd5(t) {
  const reversed = (String(t * 177) + "1").split("").reverse().join("");
  return BigInt(reversed).toString(16);
}

function b64encode(bytes) {
  let bin = "";
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin);
}

function b64decode(str) {
  const bin = atob(str);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

// ---------------- 调用 API ----------------
async function callApi(path, params, timeoutMs = 8000) {
  const t = Date.now();
  const key = apiKey(t);
  const payload = JSON.stringify(params);
  const enc = await aesCbcEncrypt(key, new TextEncoder().encode(payload));
  const body = "data=" + encodeURIComponent(b64encode(enc));
  const url = BASE + "/awsapi" + path + "?md5=" + apiMd5(t);

  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const resp = await fetch(url, {
      method: "POST",
      headers: {
        "User-Agent": UA,
        "Referer": BASE + "/",
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "X-Requested-With": "XMLHttpRequest",
        "Accept": "application/json, text/javascript, */*; q=0.01",
      },
      body,
      signal: ctrl.signal,
    });
    clearTimeout(timer);
    const json = await resp.json();
    if (json.code !== 200) return null;
    const dec = await aesCbcDecrypt(key, b64decode(json.data));
    return JSON.parse(new TextDecoder().decode(dec));
  } catch (e) {
    clearTimeout(timer);
    return null;
  }
}

// ---------------- 获取单个分类全量数据 (突破 total=1 限制) ----------------
async function fetchAllPages(params) {
  let allRows = [];
  let pg = 1;
  while (pg <= MAX_PAGES) {
    const p = { ...params, order: params.order || "desc", page: String(pg), size: String(PAGE_SIZE) };
    const data = await callApi("/vod/search.php", p);
    if (!data || !data.rows || data.rows.length === 0) break;
    
    allRows = allRows.concat(data.rows);
    
    // 如果不满一页，说明到最后一页了
    if (data.rows.length < PAGE_SIZE) break;
    pg++;
  }
  return allRows;
}

// ---------------- M3U 生成 ----------------
function escapeM3U(str) {
  return String(str || "").replace(/[",\n\r]/g, " ").trim();
}

function buildM3U(host, groups) {
  const lines = ["#EXTM3U"];
  for (const g of groups) {
    if (!g.items || g.items.length === 0) continue;
    lines.push(`#EXTINF:-1 tvg-id="${escapeM3U(g.name)}" tvg-name="${escapeM3U(g.name)}" tvg-logo="${g.logo || ""}" group-title="${escapeM3U(g.name)}",${escapeM3U(g.name)}`);
    for (const it of g.items) {
      const logo = it.logo || g.logo || "";
      const proxy = `${host}/play?id=${encodeURIComponent(it.id)}`;
      lines.push(`#EXTINF:-1 tvg-id="${escapeM3U(it.id)}" tvg-name="${escapeM3U(it.name)}" tvg-logo="${logo}" group-title="${escapeM3U(g.name)}",${escapeM3U(it.name)}`);
      lines.push(proxy);
    }
  }
  return lines.join("\n") + "\n";
}

// ---------------- 主入口 ----------------
export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;
    const host = url.origin;

    try {
      if (path === "/live.m3u" || path === "/live" || path === "/") {
        return await handleLiveM3U(host);
      }
      if (path === "/play") {
        return await handlePlay(url);
      }
      if (path === "/img") {
        return await handleImg(url);
      }
      return new Response("Not Found. Use /live.m3u", { status: 404 });
    } catch (e) {
      return new Response("Error: " + (e && e.message ? e.message : String(e)), { status: 500 });
    }
  },
};

// ---------------- /live.m3u 处理 (全量并发) ----------------
async function handleLiveM3U(host) {
  // 1. 置顶固定分组
  const topGroup = {
    name: TOP_GROUP,
    logo: TOP_LOGO,
    items: [
      {
        name: "☁️官网地址jsnzkpg.com",
        id: "__fixed__",
        logo: TOP_LOGO,
      },
    ],
  };

  // 2. 并发请求所有分类
  const fetchPromises = CATS.map(async ([tid, name, params]) => {
    try {
      const rows = await fetchAllPages(params);
      return { name, rows };
    } catch (e) {
      return { name, rows: [] };
    }
  });

  const results = await Promise.all(fetchPromises);

  // 3. 汇总并全局去重 (同一部剧可能在多个分类出现)
  const globalSeen = new Set();
  const groups = [topGroup];

  for (const res of results) {
    const items = [];
    for (const r of res.rows) {
      const vid = String(r.vodId);
      if (!vid || globalSeen.has(vid)) continue;
      globalSeen.add(vid);
      
      let finalName = r.vodName || vid;
      if (r.vodHits) finalName += ` [${r.vodHits}人气]`;
      
      items.push({
        name: finalName,
        id: vid,
        logo: r.vodPic ? `${host}/img?url=${encodeURIComponent(r.vodPic)}` : TOP_LOGO,
      });
    }
    
    if (items.length > 0) {
      groups.push({ name: res.name, logo: TOP_LOGO, items });
    }
  }

  const m3u = buildM3U(host, groups);
  return new Response(m3u, {
    status: 200,
    headers: {
      "Content-Type": "application/vnd.apple.mpegurl; charset=utf-8",
      "Access-Control-Allow-Origin": "*",
      "Cache-Control": "public, max-age=300",
    },
  });
}

// ---------------- /play 处理 ----------------
async function handlePlay(url) {
  const id = url.searchParams.get("id") || "";

  if (id === "__fixed__") {
    return Response.redirect(FIXED_VIDEO_URL, 302);
  }

  if (!id) return new Response("Missing id", { status: 400 });

  let playUrl = "";

  try {
    const info = await callApi("/vod/info.php", { id: parseInt(id) });
    if (info) {
      if (info.code && /^[0-9a-f]{32}$/i.test(info.code)) {
        playUrl = BASE + "/api/m3u8/" + info.code.toLowerCase() + ".m3u8";
      } else if (info.vodPlayUrl) {
        playUrl = info.vodPlayUrl.startsWith("http") ? info.vodPlayUrl : BASE + info.vodPlayUrl;
      }
    }
  } catch (e) {}

  if (!playUrl) return new Response("Stream not found", { status: 404 });
  return Response.redirect(playUrl, 302);
}

// ---------------- /img 代理 ----------------
async function handleImg(url) {
  const raw = url.searchParams.get("url") || "";
  if (!raw) return new Response("Missing url", { status: 400 });

  try {
    const resp = await fetch(raw, {
      headers: { "User-Agent": UA, "Referer": BASE + "/" },
    });
    if (!resp.ok) return new Response("Fetch failed", { status: 502 });
    let buf = new Uint8Array(await resp.arrayBuffer());

    const rev = new Uint8Array(buf.length);
    for (let i = 0; i < buf.length; i++) rev[i] = buf[buf.length - 1 - i];

    let use = buf;
    if (isImage(rev)) use = rev;
    else if (isImage(buf)) use = buf;

    return new Response(use, {
      headers: {
        "Content-Type": guessCT(use),
        "Cache-Control": "public, max-age=86400",
        "Access-Control-Allow-Origin": "*",
      },
    });
  } catch (e) {
    return new Response("Error", { status: 502 });
  }
}

function isImage(d) {
  if (d.length < 12) return false;
  if (d[0] === 0xff && d[1] === 0xd8) return true; // JPEG
  if (d[0] === 0x89 && d[1] === 0x50) return true; // PNG
  if (d[0] === 0x47 && d[1] === 0x49) return true; // GIF
  if (d[8] === 0x57 && d[9] === 0x45) return true; // WEBP
  return false;
}

function guessCT(d) {
  if (d.length >= 3 && d[0] === 0xff && d[1] === 0xd8) return "image/jpeg";
  if (d.length >= 4 && d[0] === 0x89 && d[1] === 0x50) return "image/png";
  if (d.length >= 3 && d[0] === 0x47 && d[1] === 0x49) return "image/gif";
  if (d.length >= 12 && d[8] === 0x57 && d[9] === 0x45) return "image/webp";
  return "image/jpeg";
}